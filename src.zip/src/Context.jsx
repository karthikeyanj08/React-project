import React, { useContext } from "react";
import { useState } from "react";

const Context = React.createContext()

const Wellprovider = ({children})=>{
    const [orderdata,setorderdata] = useState([])
    function kj(sakil){
  console.log(sakil.name)
  console.log(sakil.price)
  console.log(sakil.image)
    
  
  setorderdata([...orderdata ,sakil])
    }
/*   orderdata.map((ab)=>{
console.log(ab.name)
  })
 */return(

    <Context.Provider value={{kj,orderdata}}>
        {children}
    </Context.Provider>
)
}
const Useglobalvalue =()=>{
    return(
        useContext(Context)
    )
}
export {Wellprovider,Useglobalvalue};