import Pepperoni from "../ASD/pepperoni.jpg";
import Margherita from "../ASD/margherita.jpg";
import Chesseburst from "../ASD/pedrotechspecial.jpg";
import Vegan from "../ASD/vegan.jpg";
import Pineapple from "../ASD/pineapple.jpg";
import Expensive from "../ASD/expensive.jpg";


  export const MenuList = [
  
  
  
  {
    name: "Pepperoni Pizza",
    image: Pepperoni,
    price : 499.00,
    id:1
  },
  {
    name: "Margherita Pizza",
    image: Margherita,
    price: 599.00,
    id:2
  },
  {
    name: "Cheeseburst",
    image: Chesseburst,
    price: 399.00,
    id:3
  },
  {
    name: "Vegan Pizza",
    image: Vegan,
    price: 399.00,
    id:4
  },
  {
    name: "Pineapple Pizza",
    image: Pineapple,
    price: 659.00,
    id:5
  },
  {
    name: "Olive special",
    image: Expensive,
    price: 599.00,
    id:6
  },
]; 


 

