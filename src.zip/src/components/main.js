import About from "../pages/About";
import Contact from "../pages/Contact";
import Menu from "../pages/Header";
import Home from "../pages/Home"
import Order from "../pages/order";

const Main =()=>{
    return (
        <>  
         <Home/>  
         <Menu/>
        <About/>
        <Contact/>
        <Order/>
        
        
        </>
    )
}
export default Main;